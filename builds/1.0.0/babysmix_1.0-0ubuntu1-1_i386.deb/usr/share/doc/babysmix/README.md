BabySmix
========

Ubuntu targetted baby game based on and inspired by Scott Hanselman's much-loved Baby Smash! http://www.hanselman.com/babysmash/

To build, first install libx11-dev, then qmake followed by make.
